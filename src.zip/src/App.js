import React from "react";
import "./App.css";
import Pizza from "./components/pizza/Pizza";
function App() {
  return (
  <Pizza />);
}

export default App;
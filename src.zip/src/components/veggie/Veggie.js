import React from "react";

function Veggie() {
  return (
    <div>
      <div className="vegies">
        <div className="veg-1" />
        <div className="veg-2" />
        <div className="veg-3" />
        <div className="veg-4" />
        <div className="veg-5" />
        <div className="veg-6" />
        <div className="veg-7" />
        <div className="veg-8" />
        <div className="veg-9" />
        <div className="veg-10" />
        <div className="veg-11" />
        <div className="veg-12" />
        <div className="veg-13" />
      </div>
    </div>
  );
}

export default Veggie;
import React from "react";

function Mushroom() {
  return (
    <div>
      <div className="mushrooms">
        <div className="cup-1" />
        <div className="stem-1" />
        <div className="cup-2" />
        <div className="stem-2" />
        <div className="cup-3" />
        <div className="stem-3" />
        <div className="cup-4" />
        <div className="stem-4" />
        <div className="cup-5" />
        <div className="stem-5" />
        <div className="cup-6" />
        <div className="stem-6" />
        <div className="cup-7" />
        <div className="stem-7" />
      </div>

      <div className="mushrooms">
        <div className="cup-8" />
        <div className="stem-8" />
      </div>
    </div>
  );
}

export default Mushroom;
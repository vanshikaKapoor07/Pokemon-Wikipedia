import React from "react";

function Tomato() {
  return (
    <div>
      <div className="tomatoes">
        <div className="tomato-1" />
        <div className="tomato-2" />
        <div className="tomato-3" />
        <div className="tomato-4" />
        <div className="tomato-5" />
        <div className="tomato-6" />
        <div className="tomato-7" />
        <div className="tomato-8" />
      </div>

      <div className="tomatoes">
        <div className="tomato-9" />
        <div className="tomato-10" />
      </div>
    </div>
  );
}

export default Tomato;
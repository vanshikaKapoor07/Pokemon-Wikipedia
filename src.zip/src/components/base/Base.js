import React from "react";

function Base() {
  return (
    <div>
      <div className="pizza-base-1" />
      <div className="pizza-base-2" />
      <div className="slice-base-1" />
      <div className="slice-base-2" />
    </div>
  );
}

export default Base;